import 'package:flutter/material.dart';
import 'package:flutter_application_1/responsive/screens/web_screen_layout.dart';
import 'package:flutter_application_1/responsive/screens/mobile_screen_laytout.dart';

class Responsive_Layout extends StatelessWidget {

  final MobileScreenLayout MobilescreenLayout;
  final WebScreenLayout WebscreenLayout;

  const Responsive_Layout(
      {super.key,
      required this.WebscreenLayout,
      required this.MobilescreenLayout});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 600) {
          return WebscreenLayout; // WEB SCREEN
        }
        return MobilescreenLayout;
      },
    );
  }
}
